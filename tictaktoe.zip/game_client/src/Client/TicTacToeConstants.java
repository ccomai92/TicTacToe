package Client;

public interface TicTacToeConstants {
    public static int PLAYER1 = 10; // Indicate player 1
    public static int PLAYER2 = 20; // Indicate player 2
    public static int PLAYER1_WON = 30; // Indicate player 1 won
    public static int PLAYER2_WON = 40; // Indicate player 2 won
    public static int DRAW = 50; // Indicate a draw
    public static int CONTINUE = 60; // Indicate to continue
}
