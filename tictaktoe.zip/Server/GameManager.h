#ifndef GAME_MANAGER_H
#define GAME_MANAGER_H

/*
 * Game Manager class which takes care of the logic of
 * game and connection
 */

class GameManager {
public:
    GameManager();
    ~GameManager();
private:
    int dummy;
};

#endif