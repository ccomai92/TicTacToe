# include "GameManager.h"

using namespace std;

GameManager::GameManager() {

}
GameManager::~GameManager() {

}